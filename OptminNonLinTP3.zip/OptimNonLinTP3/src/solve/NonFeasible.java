package solve;

/**
 * throw when a non feasible solution is detected
 * 
 * @author dorian
 *
 */
public class NonFeasible extends Exception {
	private static final long serialVersionUID = 1L;
}
