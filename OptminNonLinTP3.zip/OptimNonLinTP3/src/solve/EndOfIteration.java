package solve;

public class EndOfIteration extends Exception {

	private static final long serialVersionUID = 1L;

}
