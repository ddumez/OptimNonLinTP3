package solve;
import line.LineSearch;
import line.Dichotomy;
import func.RealFunc;
import util.Matrix;
import util.Singularity;
import util.Vector;
import java.util.TreeSet;
import java.lang.Integer;

/**
 * The projected gradient algorithm for non-linear optimization under 
 * linear inequalities.
 * 
 * @author G Chabert
 *
 */
public class ProjGradient extends Algorithm {
	
	/**
	 *  Minimal step for the line search
	 */

	final static double MIN_ALPHA=1e-20;
	/**
	 *  Minimal norm of the gradient under which Khun-Tucker 
	 *  conditions are applied.
	 */
	public final static double MIN_GRAD_NORM=1e-10;
	
	/**
	 * Threshold under which an equality is considered as satisfied. 
	 *
	 * When for a constraint g<=0, |g(x)|<ALMOST_ZERO, the
	 * constraint is considered to be active. 
	 */
	public final static double ALMOST_ZERO=1e-08;

	// Number of variables
	int n;
	// Number of constraints
	int m;
	// Matrix of constraints
	Matrix A;
	// Right-hand vectors of constraints
	Vector b;
	// Function to minimize
	RealFunc f;
	// Line search
	LineSearch line;
	//dichotomy if we need one
	Dichotomy dic;
	//set of active constrains
	TreeSet<Integer> active;
	//current point
	Vector x;
		
	public Vector getSol() { return x;}

	/**
	 * Check that x is feasible (the method raises and error if x is infeasible).
	 * 
	 * The projected gradient algorithm only yield feasible vectors.
	 * Call this method at each iteration, to check that your code is correct.
	 * 
	 * @param x - the current vector
	 * @throws NonFeasible if x is a non feasible point
	 */
	private void check_feasible(Vector x) throws NonFeasible {
		Vector y = A.mult(x);
		boolean res = true;
		for(int i = 0; i<A.nb_rows(); i++) {
			res = res && (y.get(i) <= b.get(i) + ALMOST_ZERO);
		}
		
		if (! res) throw new NonFeasible();

	}
	
	
	/**
	 * This constructor:
	 * - build the projected gradient algorithm for minimizing f
	 *   under constraints Ax<=b. 
	 * - check that the initial point x0 is feasible.
	 * - determine the initial set of active constraints.
	 * 
	 */
	public ProjGradient(Matrix A, Vector b, RealFunc f, LineSearch l) {
	
		this.A = A;
		this.b = b;
		this.f = f;
		this.line = l;
		this.dic = new Dichotomy(f);
		this.n = A.nb_cols(); //the constraint matrix have one column for each variable
		this.m = A.nb_rows(); //and one row for each constraint
		
	}
	
	/**
	 * initialize the search :
	 *  - save x0
	 *  - compute the set of actives constraints
	 */
	public void start(Vector x0) {
		x = new Vector(x0);
		//compute the set of active constraint
		for (int i =0; i<n; i++) {
			if ((x0.get(i) <= b.get(i) + ALMOST_ZERO) && (x0.get(i) >= b.get(i) - ALMOST_ZERO) ) {
				active.add(i);
			}
		}
	}
	
	/**
	 * Calculate the next iterate.
	 * 
	 * @return x (the same reference) if the solution is reached.
	 */
	public void compute_next() throws EndOfIteration {
		
		Vector d = computed();
		if (d.norm()  <= MIN_GRAD_NORM) {
			boolean flag = true;
			
			Matrix Ak = new Matrix( active.size() , n);
			int compt = 0;
			for(int i : active) {
				for(int j=0; j<n; j++) {
					Ak.set(compt, j, A.get_row(i).get(j));
				}
				compt = compt+1;
			}
			
			Vector lambda;
			try{
				lambda = new Vector ( ((Ak.mult(Ak.transpose())).inverse()).mult( Ak.mult(f.grad(x)) ).leftmul(-1.0) );
				for(int i=0; i<n; i++) {
					if (lambda.get(i) >= ALMOST_ZERO) {
						flag = false;
						active.remove(i);
					}
				}
			}catch(Singularity si) {
				System.out.println("probleme lors de l'inversion d'une matrice");
				lambda = new Vector(n);
			}
			
			if (flag) {
				throw new EndOfIteration();
			}
		} else {
			double alpha = lineSearch(d);
			x = x.add(d.leftmul(alpha));
			
			for (int i =0; i<n; i++) {
				if ((x.get(i) <= b.get(i) + ALMOST_ZERO) && (x.get(i) >= b.get(i) - ALMOST_ZERO) ) {
					active.add(i); //no add if already in
				}
			}
			
			try{
				check_feasible(x);
			} catch(NonFeasible ex) {
				System.out.println("vecteur non admissible obtenu");
				throw new EndOfIteration();
			}
		}
		
	}
	
	/**
	 * compute an alpha such that x+a*d decrease the objective function
	 * <p>
	 * It doesn't change the set of active constraint or x
	 * 
	 * @return the alpha computed
	 */
	private double lineSearch(Vector d) {
		double res = line.search(x, d); //computation of the best alpha
		
		if (res < 0) { //we take the max value to observe the first constraint, it will be adjust later
			res = b.get(0) / A.mult(x).get(0);
		}
		
		Vector c = A.mult(x.add(d.leftmul(res)));
		
		for (int i=0; i<m; i++) { //for each constraint non active
			if ( (! active.contains(i)) && (c.get(i) >= b.get(i) + ALMOST_ZERO) ) {
				//the constraint isn't observe
				res = b.get(i) / A.mult(x).get(i); //the max value of res who observe the constraint
				c = A.mult(x.add(d.leftmul(res)));
			}
		}
		
		//if we don't decrease
		c = x.add(d.leftmul(res));
		if (f.eval(c) >= f.eval(x)) {
			res = dic.search(x,c);
		}
		
		return res;
	}
	
	/**
	 * compute the slope direction
	 * 
	 * @return the vector of the slope direction
	 */
	private Vector computed() {
		Vector res = f.grad(x).leftmul(-1); //opposite of the f gradient
		Matrix Ak = new Matrix( active.size() , n);
		int compt = 0;
		for(int i : active) {
			for(int j=0; j<n; j++) {
				Ak.set(compt, j, A.get_row(i).get(j));
			}
			compt = compt+1;
		}
		Matrix Ptmp;
		try{
			Ptmp = new Matrix ( Ak.transpose().mult( ((Ak.mult(Ak.transpose())).inverse()).mult(Ak) ) );
		}catch(Singularity si) {
			System.out.println("probleme lors de l'inversion d'une matrice");
			Ptmp = new Matrix(0,0);
		}
		Matrix P = Matrix.identity(n).sub(Ptmp);
		
		return P.mult(res.leftmul(-1.0));
	}
}
