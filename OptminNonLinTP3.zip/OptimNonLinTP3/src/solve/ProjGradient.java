package solve;
import line.LineSearch;
import line.Dichotomy;
import func.RealFunc;
import util.Matrix;
import util.Singularity;
import util.Vector;

import java.util.Iterator;
import java.util.TreeSet;
import java.lang.Integer;
import java.lang.Math;

/**
 * The projected gradient algorithm for non-linear optimization under 
 * linear inequalities.
 * 
 * @author G Chabert
 *
 */
public class ProjGradient extends Algorithm {
	
	/**
	 *  Minimal step for the line search
	 */

	final static double MIN_ALPHA=1e-20;
	/**
	 *  Minimal norm of the gradient under which Khun-Tucker 
	 *  conditions are applied.
	 */
	public final static double MIN_GRAD_NORM=1e-10;
	
	/**
	 * Threshold under which an equality is considered as satisfied. 
	 *
	 * When for a constraint g<=0, |g(x)|<ALMOST_ZERO, the
	 * constraint is considered to be active. 
	 */
	public final static double ALMOST_ZERO=1e-08;

	// Number of variables
	int n;
	// Number of constraints
	int m;
	// Matrix of constraints
	Matrix A;
	// Right-hand vectors of constraints
	Vector b;
	// Function to minimize
	RealFunc f;
	// Line search
	LineSearch line;
	//dichotomy if we need one
	Dichotomy dic;
	//set of active constrains
	TreeSet<Integer> active;

	/**
	 * Check that x is feasible (the method raises and error if x is infeasible).
	 * 
	 * The projected gradient algorithm only yield feasible vectors.
	 * Call this method at each iteration, to check that your code is correct.
	 * 
	 * @param x - the current vector
	 * @throws NonFeasible if x is a non feasible point
	 */
	private void check_feasible(Vector x) throws NonFeasible {
		Vector y = A.mult(x);
		boolean res = true;
		for(int i = 0; i<A.nb_rows(); i++) {
			res = res && (y.get(i) <= b.get(i) + ALMOST_ZERO);
		}
		
		if (! res) throw new NonFeasible();

	}
	
	
	/**
	 * This constructor:
	 * - build the projected gradient algorithm for minimizing f
	 *   under constraints Ax<=b. 
	 * - check that the initial point x0 is feasible.
	 * - determine the initial set of active constraints.
	 * 
	 */
	public ProjGradient(Matrix A, Vector b, RealFunc f, LineSearch l) {
	
		this.A = A;
		this.b = b;
		this.f = f;
		this.line = l;
		this.dic = new Dichotomy(f);
		this.active = new TreeSet<Integer>();
		this.n = A.nb_cols(); //the constraint matrix have one column for each variable
		this.m = A.nb_rows(); //and one row for each constraint
		
	}
	
	/**
	 * initialize the search :
	 *  - save x0
	 *  - compute the set of actives constraints
	 */
	public void start(Vector x0) {

System.out.println("x0 = "+x0);
System.out.println("f(x0) = "+f.eval(x0));
		
		super.start(x0);
		//compute the set of active constraint
		Vector y = new Vector (A.mult(x0));
		for (int i =0; i<m; i++) {
			if ( Math.abs(y.get(i)-b.get(i)) <= ALMOST_ZERO) {
				active.add(i);
			}
		}
		
System.out.println("active : "+active);
		
	}
	
	/**
	 * Calculate the next iterate.
	 * 
	 * @return x (the same reference) if the solution is reached.
	 */
	public void compute_next() throws EndOfIteration {
System.out.println("\n\n");
		
		Vector d = computed(); //search of the descent direction
System.out.println("direction : "+d);

		if (d.norm()  <= MIN_GRAD_NORM) { //maybe finish ?
			
			//matrix of the active constraint
			Matrix Ak = new Matrix( active.size() , n);
			int compt = 0;
			for(int i : active) {
				for(int j=0; j<n; j++) {
					Ak.set(compt, j, A.get_row(i).get(j));
				}
				compt = compt+1;
			}
			
			//lagrangian  multiplier
			Vector lambda;
			compt = 0;
			Integer i;
			try{
				lambda = new Vector ( ( ( (Ak.mult(Ak.transpose())).inverse() ).mult( Ak.mult(f.grad(iter_vec))) ).leftmul(-1.0) );
				Iterator<Integer> it = active.iterator();
				while(it.hasNext()) {
					i = it.next();
					if (lambda.get(compt) <= -1.0*ALMOST_ZERO) {
System.out.println("contrainte "+i+" desactivé");
						it.remove();
					}
					++compt;
				}
			}catch(Singularity si) {
				System.out.println("probleme lors de l'inversion d'une matrice");
				lambda = new Vector(n);
			}
			
System.out.println("iter_vec : "+iter_vec);
System.out.println("f(x0) = "+f.eval(iter_vec));
System.out.println("active : "+active);
System.out.println("Ak : "+Ak);
System.out.println("lambda : "+lambda);

			if (0 == compt) { //all lagrangian multiplier are positive
				throw new EndOfIteration();
			} else {
				compute_next();
			}
			
		} else {
			double alpha = lineSearch(d); //the best alpha for the direction
System.out.println("alpha = "+alpha);
			iter_vec = iter_vec.add(d.leftmul(alpha)); //Maj of iter_vec
			
			Vector y = new Vector (A.mult(iter_vec)); //activation of active constraint
			for (int i =0; i<m; i++) {
				if ( Math.abs(y.get(i)-b.get(i)) <= ALMOST_ZERO) {
					active.add(i); //if already in, dosn't add
				}
			}

System.out.println("iter_vec : "+iter_vec);
System.out.println("f(x0) = "+f.eval(iter_vec));
System.out.println("active : "+active);
			
			try{
				check_feasible(iter_vec);
			} catch(NonFeasible ex) {
				System.out.println("vecteur non admissible obtenu");
				throw new EndOfIteration();
			}
		}
		
	}
	
	/**
	 * compute an alpha such that x+a*d decrease the objective function
	 * <p>
	 * It doesn't change the set of active constraint or x
	 * 
	 * @return the alpha computed
	 */
	private double lineSearch(Vector d) {
		double res = line.search(iter_vec, d); //computation of the best alpha
		
		if (res < 0) { //we take the max value to observe the first constraint, it will be adjust later
			res = b.get(0) / A.mult(iter_vec).get(0);
		}
		
		Vector c = A.mult(iter_vec.add(d.leftmul(res)));
		
		for (int i=0; i<m; i++) { //for each constraint non active
			if ( (! active.contains(i)) && (c.get(i) >= b.get(i) + ALMOST_ZERO) ) {
				//the constraint isn't observe
				res = b.get(i) / A.mult(iter_vec).get(i); //the max value of res who observe the constraint
				c = A.mult(iter_vec.add(d.leftmul(res)));
			}
		}
		
		//if we don't decrease
		c = iter_vec.add(d.leftmul(res));
		if (f.eval(c) >= f.eval(iter_vec)) {
			res = dic.search(iter_vec,c);
		}
		
		return res;
	}
	
	/**
	 * compute the slope direction
	 * 
	 * @return the vector of the slope direction
	 */
	private Vector computed() {
		Vector res = f.grad(iter_vec).leftmul(-1); //opposite of the f gradient
		Matrix Ak = new Matrix( active.size() , n);
		int compt = 0;
		for(int i : active) {
			for(int j=0; j<n; j++) {
				Ak.set(compt, j, A.get_row(i).get(j));
			}
			compt = compt+1;
		}
		Matrix Ptmp;
		try{
			Ptmp = new Matrix ( Ak.transpose().mult( ((Ak.mult(Ak.transpose())).inverse()).mult(Ak) ) );
		}catch(Singularity si) {
			System.out.println("probleme lors de l'inversion d'une matrice");
			Ptmp = new Matrix(0,0);
		}
		Matrix P = Matrix.identity(n).sub(Ptmp);
		
		return P.mult(res.leftmul(-1.0));
	}
}
